# Dataset

Download the iris dataset 'iris (1).data' from the hw4.zip folder
Another dataset directly imported (fetch_openml) MNIST dataset

--------------------------------------------------------------------------------------

## Requirements
- Python 3.10 or higher
- Pandas
- scikit-learn

--------------------------------------------------------------------------------------

- Open a terminal or command prompt and run install all the libraries
- Place the iris data file in the same directory as the script.
- Run the python program using the command python hw_4_ml.py in your terminal or command prompt. 
- You can close the window to exit the program.

