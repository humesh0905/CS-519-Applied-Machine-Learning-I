# Dataset

Download the Iris dataset 'iris.data' from the hw2.zip folder
Download the lung cancer dataset 'lung-cancer.data' from the hw2.zip folder

--------------------------------------------------------------------------------------

## Requirements
- Python 3.10 or higher
- Pandas
- sys
- numpy
- Matplotlib

--------------------------------------------------------------------------------------

- Open a terminal or command prompt and run: pip install pandas matplotlib numpy
- Place the two data files in the same directory as the script.
- Run the python program using the command python hw2_ML.py in your terminal or command prompt. 
- The program will print the results and show the 6 plot for errors/costs for all the iterations in a new window. 
- You can close the window to exit the program.

