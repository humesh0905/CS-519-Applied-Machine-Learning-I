# Iris Dataset

Download the Iris dataset 'iris (1).data' from the hw1.zip folder

--------------------------------------------------------------------------------------

## Requirements
- Python 3.10 or higher
- Pandas
- Matplotlib
- Seaborn

--------------------------------------------------------------------------------------

- Open a terminal or command prompt and run: pip install pandas matplotlib seaborn
- Place the `iris (1).data` file in the same directory as the script.
- Run the python program using the command python hw1.py in your terminal or command prompt. 
- The program will print the results of the tasks 1 to 4 and show the scatter plot for task 5 in a new window. 
- You can close the window to exit the program.

