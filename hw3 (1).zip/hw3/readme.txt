# Dataset

For the digit dataset imported from sklearn.datasets / import load_digits
Download the lung cancer dataset 'lung-cancer.data' from the hw3.zip folder

--------------------------------------------------------------------------------------

## Requirements
- Python 3.10 or higher
- Pandas
- scikit-learn
- StandardScaler
- GridSearchCV
- SimpleImputer
- time

--------------------------------------------------------------------------------------

- Open a terminal or command prompt and run install all the libraries
- Place the lung-cancer data file in the same directory as the script.
- Run the python program using the command python hw3_ml.py in your terminal or command prompt. 
- The program will print the results of the (both datasets) each classifier, best parameters, Accuracy for the both train and test and the running time for the training and testing.
- You can close the window to exit the program.

