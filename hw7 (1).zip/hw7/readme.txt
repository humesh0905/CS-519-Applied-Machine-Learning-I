# Dataset
 
1) MNIST Dataset - directly imported from sklearn.datasets

--------------------------------------------------------------------------------------

## Requirements
- Python 3.10 or higher
- Pandas
- PyTorch
- scikit-learn
- torchvision
--------------------------------------------------------------------------------------

- Open a terminal or command prompt and run install all the libraries
- Run the python program using the command python hw7.py in your terminal or command prompt. 
- You can close the window to exit the program.