# Dataset

Dataset directly imported using fetch_california_housing from sklearn.datasets

--------------------------------------------------------------------------------------

## Requirements
- Python 3.10 or higher
- Pandas
- scikit-learn

--------------------------------------------------------------------------------------

- Open a terminal or command prompt and run install all the libraries
- Run the python program using the command python ml_5.py in your terminal or command prompt. 
- You can close the window to exit the program.