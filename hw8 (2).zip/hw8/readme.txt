# Dataset
 
1) Digit Dataset - directly imported from sklearn.datasets
2) Mammographic Mass dataset (Download from my submission hw8.zip)

--------------------------------------------------------------------------------------

## Requirements
- Python 3.10 or higher
- Pandas
- PyTorch
- scikit-learn
--------------------------------------------------------------------------------------

- Open a terminal or command prompt and run install all the libraries
- Run the python program using the command python hw8.py in your terminal or command prompt. 
- You can close the window to exit the program.